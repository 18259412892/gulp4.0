const a = ()=>{
    console.log(2)
}